# Arduino-Code-Dump

This is just a repository to store all of my arduino code in one area so anyone can have access to it. Later, I can write a readme for how I design my programs in hope that something may become standardized in the future.