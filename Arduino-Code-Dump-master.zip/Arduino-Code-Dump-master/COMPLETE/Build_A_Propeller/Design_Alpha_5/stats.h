



#ifndef analyze_h
#define analyze_h

class Stats
{
		public:
				Stats();
				int average(int[], int size);
				int stdDev(int[], int size);
};

#endif
